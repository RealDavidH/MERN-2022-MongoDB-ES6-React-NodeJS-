class Ninja {
    constructor(name){
        this.name = name
        this.health = 100
        this.speed = 3
        this.strength = 3
    }
    sayName(){
        console.log(`My name is ${this.name}`)
    }
    showStats(){
        console.log(`Ninja: ${this.name}, Speed: ${this.speed}, Strength; ${this.strength}`)
    }
    drinkSake(){
        this.health += 10;
        console.log(`${this.name} drank sake, and gained 10 health! ${this.health}`)
    }
}

const ninja1 = new Ninja("David")

console.log(ninja1.sayName())