import { createContext } from "react";

export const Wrapper = createContext({});