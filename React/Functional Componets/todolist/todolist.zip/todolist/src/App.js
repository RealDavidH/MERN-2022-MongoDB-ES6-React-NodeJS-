import Form from "./components/Form";


function App() {
  return (
    <div className="text-center mt-2">
      <h1>To Do List:</h1>
      <Form />
    </div>
  );
}

export default App;
