import Form from "./components/Form"

function App() {
  return (
    <div className="text-white bg-dark">
      <Form />
    </div>
  );
}

export default App;
