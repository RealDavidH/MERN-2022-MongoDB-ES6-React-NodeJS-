import Form from "./components/Form";


function App() {
    return (
    <div>
      <Form />
    </div>
    );
}

export default App;
