import CreateUser from "./components/CreateUser";

function App() {
    return (
    <div className="text-center d-flex justify-content-center text-white bg-dark">
      <CreateUser />
    </div>);
}

export default App;
