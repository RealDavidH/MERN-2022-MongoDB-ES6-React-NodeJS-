import { createContext } from "react";

export const Pokemon = createContext({});